plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.pip"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.pip"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "7.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.alphacephei:vosk-android:0.3.47")
}
