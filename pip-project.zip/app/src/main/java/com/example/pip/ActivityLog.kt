package com.example.pip

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

object ActivityLog {
    private fun p(ctx: Context) = ctx.getSharedPreferences("pip", Context.MODE_PRIVATE)

    fun add(ctx: Context, text: String) {
        try {
            val arr = JSONArray(p(ctx).getString("log", "[]"))
            arr.put(JSONObject().put("t", text).put("ts", System.currentTimeMillis()))
            while (arr.length() > 30) arr.remove(0)
            p(ctx).edit().putString("log", arr.toString()).apply()
        } catch (e: Exception) {}
    }

    fun all(ctx: Context): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        try {
            val arr = JSONArray(p(ctx).getString("log", "[]"))
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i)
                out.add(o.getString("t") to o.getLong("ts"))
            }
        } catch (e: Exception) {}
        return out
    }

    fun err(ctx: Context, msg: String) {
        p(ctx).edit().putString("err", msg.take(400) + " (" + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()) + ")").apply()
    }

    fun lastErr(ctx: Context): String = p(ctx).getString("err", "") ?: ""
    fun clearErr(ctx: Context) { p(ctx).edit().remove("err").apply() }

    fun ago(ts: Long): String {
        val m = (System.currentTimeMillis() - ts) / 60000
        return if (m < 1) "just now" else if (m < 60) "$m mins ago" else if (m < 1440) "${m / 60} hours ago" else "${m / 1440} days ago"
    }
}
