package com.example.pip

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {
    private val BG = Color.parseColor("#070B14")
    private val CARD = Color.parseColor("#0D1526")
    private val BORDER = Color.parseColor("#1B2C4A")
    private val ACCENT = Color.parseColor("#36A8FF")
    private val TEXT = Color.parseColor("#EAF2FF")
    private val MUTED = Color.parseColor("#8DA2C0")
    private val GREEN = Color.parseColor("#2BD9A0")
    private val RED = Color.parseColor("#FF4D5E")

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private lateinit var navItems: List<TextView>
    private var tab = 0
    private var dot: TextView? = null
    private var statusTitle: TextView? = null
    private var statusSub: TextView? = null
    private var recent: LinearLayout? = null
    private val tick = object : Runnable {
        override fun run() {
            refreshHome()
            ui.postDelayed(this, 1500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = Color.parseColor("#0A1020")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildNav(), LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(root)
        show(0)
        if (intent.getBooleanExtra("autostart", false)) startJarvis(true)
    }

    override fun onResume() {
        super.onResume()
        show(tab)
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    // ---------- small UI helpers ----------
    private fun prefs(): SharedPreferences = getSharedPreferences("pip", MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(fill: Int, r: Int, stroke: Int = BORDER) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun tv(s: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun card(vararg views: View): LinearLayout = col().apply {
        background = bg(CARD, 16)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        views.forEach { addView(it) }
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun pageBox() = col().apply { setPadding(dp(18), dp(16), dp(18), dp(24)) }
    private fun scroll(p: LinearLayout) = ScrollView(this).apply { addView(p) }
    private fun divider() = View(this).apply { setBackgroundColor(BORDER) }

    private fun buildNav(): View {
        val rowView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#0A1020"))
        }
        val items = listOf("⌂" to "Home", "⚡" to "Commands", "▦" to "Tools", "⚙" to "Settings")
        navItems = items.mapIndexed { i, item ->
            TextView(this).apply {
                text = item.first + "\n" + item.second
                gravity = Gravity.CENTER
                textSize = 12f
                setOnClickListener { show(i) }
            }.also { rowView.addView(it, LinearLayout.LayoutParams(0, -1, 1f)) }
        }
        return rowView
    }

    private fun show(i: Int) {
        tab = i
        content.removeAllViews()
        dot = null; statusTitle = null; statusSub = null; recent = null
        content.addView(when (i) {
            0 -> homePage()
            1 -> commandsPage()
            2 -> toolsPage()
            else -> settingsPage()
        })
        navItems.forEachIndexed { j, t -> t.setTextColor(if (j == i) ACCENT else MUTED) }
        if (i == 0) refreshHome()
    }

    // ---------- Home ----------
    private fun homePage(): View {
        val p = pageBox()
        val head = row()
        head.addView(tv("☰", 24f).apply { setOnClickListener { show(3) } }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(16) })
        val logo = col()
        logo.addView(tv("J A R V I S", 26f, ACCENT, true))
        logo.addView(tv("YOUR AI ASSISTANT", 10f, MUTED))
        head.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        val d = tv("", 14f)
        dot = d
        head.addView(d)
        p.addView(head, lp())

        val st = tv("", 16f, TEXT, true)
        val ss = tv("", 13f, MUTED)
        statusTitle = st
        statusSub = ss
        val texts = col().apply { addView(st); addView(ss) }
        val srow = row().apply {
            addView(tv("🎙", 22f), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(14) })
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv("›", 24f, MUTED))
        }
        p.addView(card(srow).apply { setOnClickListener { toggleJarvis() } }, lp(18))

        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = if (h < 12) "Good Morning" else if (h < 18) "Good Afternoon" else "Good Evening"
        val nm = prefs().getString("name", "")?.trim().orEmpty()
        p.addView(tv(if (nm.isEmpty()) part else "$part, $nm", 22f, TEXT, true).apply { gravity = Gravity.CENTER }, lp(24))
        p.addView(tv("How can I help you today?", 15f, MUTED).apply { gravity = Gravity.CENTER }, lp(4))

        val orb = OrbView(this).apply { setOnClickListener { orbTap() } }
        p.addView(orb, LinearLayout.LayoutParams(-1, dp(260)).apply { topMargin = dp(8) })

        fun quick(icon: String, title: String, sub: String, hint: String): View =
            card(tv(icon, 22f), tv(title, 15f, TEXT, true), tv(sub, 12f, MUTED)).apply {
                setOnClickListener { Toast.makeText(this@MainActivity, hint, Toast.LENGTH_LONG).show() }
            }
        fun pair(a: View, b: View) = row().apply {
            addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        }
        p.addView(pair(
            quick("📱", "Open Apps", "Launch any app", "Say: Jarvis, then open YouTube"),
            quick("✈️", "Send Message", "WhatsApp, SMS, etc.", "Say: Jarvis, then message Sam on WhatsApp hello")
        ), lp(8))
        p.addView(pair(
            quick("⏰", "Set a Reminder", "Alarms & reminders", "Say: Jarvis, then set an alarm for 7 am"),
            quick("🌐", "Search the Web", "Get information online", "Say: Jarvis, then search for the latest news")
        ), lp(12))

        val rh = row().apply {
            addView(tv("Recent Activity", 16f, TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv("View all ›", 13f, ACCENT).apply { setOnClickListener { showAll() } })
        }
        val r = col()
        recent = r
        p.addView(card(rh, r), lp(16))
        return scroll(p)
    }

    private fun refreshHome() {
        if (tab != 0) return
        val alive = JarvisService.alive
        dot?.text = if (alive) "● Online" else "● Off"
        dot?.setTextColor(if (alive) GREEN else MUTED)
        statusTitle?.text = if (alive) "Running in background" else "Jarvis is off"
        statusSub?.text = if (alive) JarvisService.statusText.ifEmpty { "Listening for your commands..." } else "Tap here to start Jarvis"
        val r = recent ?: return
        r.removeAllViews()
        val items = ActivityLog.all(this).take(3)
        if (items.isEmpty()) {
            r.addView(tv("Nothing yet. Say Jarvis to get started.", 13f, MUTED), lp(8))
        } else {
            items.forEach { r.addView(activityRow(it.first, it.second), lp(10)) }
        }
    }

    private fun activityRow(t: String, ts: Long): View = row().apply {
        addView(tv("🎙", 18f), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(12) })
        addView(tv(t.replaceFirstChar { it.uppercase() }, 14f), LinearLayout.LayoutParams(0, -2, 1f))
        addView(tv(ActivityLog.ago(ts), 11f, MUTED))
    }

    private fun showAll() {
        val items = ActivityLog.all(this)
        AlertDialog.Builder(this)
            .setTitle("Recent activity")
            .setMessage(if (items.isEmpty()) "Nothing yet." else items.joinToString("\n") { it.first + "  (" + ActivityLog.ago(it.second) + ")" })
            .setPositiveButton("Close", null)
            .show()
    }

    private fun toggleJarvis() {
        if (JarvisService.alive) {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "Jarvis stopped", Toast.LENGTH_SHORT).show()
            ui.postDelayed({ refreshHome() }, 400)
        } else startJarvis(true)
    }

    private fun orbTap() {
        if (JarvisService.alive) {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_LISTEN))
        } else startJarvis(true)
    }

    // ---------- Commands ----------
    private fun commandsPage(): View {
        val p = pageBox()
        p.addView(tv("Commands", 24f, TEXT, true), lp())
        p.addView(tv("Say Jarvis first, then any of these. You can also just talk naturally.", 13f, MUTED), lp(4))
        val groups = listOf(
            "Apps" to "open WhatsApp\nlaunch YouTube",
            "Calls and messages" to "call Mom\nmessage Sam on WhatsApp that I am late\ntext Alex I will call you later",
            "Alarms and timers" to "set an alarm for 7 30 am\nset a timer for 10 minutes",
            "Music and media" to "play some lo-fi music\npause\nnext song",
            "Phone control" to "go home\ngo back\ntake a screenshot\nscroll down\ntap Send\nturn on the flashlight\nvolume up",
            "Screen and chat" to "what is on my screen\nsummarize this\nhow are you\nremember that my birthday is in May",
            "Maps and web" to "navigate to the airport\nsearch for pizza near me"
        )
        groups.forEach { g ->
            p.addView(card(tv(g.first, 15f, ACCENT, true), tv(g.second, 14f).apply { setPadding(0, dp(6), 0, 0) }), lp(12))
        }
        return scroll(p)
    }

    // ---------- Tools ----------
    private fun toolCard(title: String, ok: Boolean?, sub: String, action: () -> Unit): View {
        val badge = when (ok) { true -> "✓ On"; false -> "✗ Off"; else -> "›" }
        val head = row().apply {
            addView(tv(title, 15f, TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv(badge, 13f, if (ok == true) GREEN else if (ok == false) RED else MUTED))
        }
        return card(head, tv(sub, 12f, MUTED).apply { setPadding(0, dp(4), 0, 0) }).apply { setOnClickListener { action() } }
    }

    private fun toolsPage(): View {
        val p = pageBox()
        p.addView(tv("Tools", 24f, TEXT, true), lp())
        p.addView(tv("Tap a card to fix or turn on each permission.", 13f, MUTED), lp(4))
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        p.addView(toolCard("Microphone, contacts and calls", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            "Needed to hear you, find contacts and place calls") { requestPermissions(perms().toTypedArray(), 1) }, lp(14))
        p.addView(toolCard("Phone control (Accessibility)", JarvisAccessibility.instance != null,
            "Home, back, scrolling, tapping and screen vision") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(10))
        p.addView(toolCard("Display over other apps", Settings.canDrawOverlays(this),
            "Lets Jarvis open apps while you are in another app") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(10))
        p.addView(toolCard("Run in background", pm.isIgnoringBatteryOptimizations(packageName),
            "Stops the battery manager from closing Jarvis") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }, lp(10))
        p.addView(toolCard("App info", null,
            "Open the 3-dot menu and choose Allow restricted settings if Accessibility is greyed out") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(10))
        val err = ActivityLog.lastErr(this)
        p.addView(card(
            tv("Last problem", 15f, TEXT, true),
            tv(if (err.isEmpty()) "None recorded." else err, 12f, if (err.isEmpty()) MUTED else RED).apply { setPadding(0, dp(4), 0, 0) },
            tv("Tap to clear", 11f, MUTED).apply { setPadding(0, dp(6), 0, 0) }
        ).apply { setOnClickListener { ActivityLog.clearErr(this@MainActivity); show(2) } }, lp(10))
        return scroll(p)
    }

    // ---------- Settings ----------
    private fun field(hint: String, key: String, secret: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(MUTED)
        setTextColor(TEXT)
        setText(prefs().getString(key, ""))
        background = bg(Color.parseColor("#0A1222"), 10)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setSingleLine()
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { prefs().edit().putString(key, s.toString().trim()).apply() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean, initial: Boolean? = null, onChange: ((Boolean) -> Unit)? = null): View {
        val sw = Switch(this).apply {
            isChecked = initial ?: prefs().getBoolean(key, def)
            setOnCheckedChangeListener { _, on ->
                prefs().edit().putBoolean(key, on).apply()
                onChange?.invoke(on)
            }
        }
        val t = col().apply { addView(tv(title, 15f)); addView(tv(sub, 12f, MUTED)) }
        return row().apply {
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sw)
            setPadding(0, dp(8), 0, dp(8))
        }
    }

    private fun infoRow(title: String, sub: String, action: (() -> Unit)? = null): View {
        val t = col().apply { addView(tv(title, 15f)); addView(tv(sub, 12f, MUTED)) }
        return row().apply {
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            if (action != null) addView(tv("›", 22f, MUTED))
            setPadding(0, dp(8), 0, dp(8))
            if (action != null) setOnClickListener { action() }
        }
    }

    private fun section(title: String, vararg views: View): View {
        val c = card(tv(title, 16f, ACCENT, true))
        views.forEach { c.addView(it, lp(10)) }
        return c
    }

    private fun settingsPage(): View {
        val p = pageBox()
        p.addView(tv("Settings", 24f, TEXT, true), lp())

        val ht = col().apply {
            addView(tv("JARVIS AI", 20f, TEXT, true))
            addView(tv("v7.0", 13f, MUTED))
            addView(tv("Smart. Fast. Always with you.", 13f, MUTED))
        }
        p.addView(card(row().apply {
            addView(OrbView(this@MainActivity), LinearLayout.LayoutParams(dp(84), dp(84)))
            addView(ht, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        }), lp(14))

        val gem = field("Paste your free Gemini key", "gemini", true)
        val eye = tv("👁", 20f).apply {
            setPadding(dp(12), 0, 0, 0)
            setOnClickListener {
                val hidden = (gem.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0
                gem.inputType = if (hidden) InputType.TYPE_CLASS_TEXT else (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
                gem.setSelection(gem.text.length)
            }
        }
        val gemRow = row().apply { addView(gem, LinearLayout.LayoutParams(0, -2, 1f)); addView(eye) }
        p.addView(section("API Configuration",
            tv("Gemini API key (free)", 13f, MUTED), gemRow,
            tv("Get a free key from Google AI Studio ↗", 13f, ACCENT).apply {
                setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) }
            },
            tv("Claude API key (optional)", 13f, MUTED), field("Paste a Claude key", "claude", true),
            tv("Your keys are stored only on this phone.", 12f, MUTED)
        ), lp(12))

        val pitch = prefs().getFloat("pitch", 1.0f)
        val voiceName = if (pitch < 0.95f) "Deep" else if (pitch > 1.1f) "Bright" else "Normal"
        p.addView(section("Assistant Settings",
            tv("Your name", 13f, MUTED), field("What should Jarvis call you?", "name"),
            tv("Voice language, like en-US or en-IN", 13f, MUTED), field("Leave empty to use your phone language", "lang"),
            infoRow("Voice type", voiceName) {
                AlertDialog.Builder(this).setTitle("Voice type")
                    .setItems(arrayOf("Deep", "Normal", "Bright")) { _, i ->
                        prefs().edit().putFloat("pitch", floatArrayOf(0.8f, 1.0f, 1.25f)[i]).apply()
                        show(3)
                    }.show()
            },
            infoRow("Wake word", "Hey Jarvis"),
            switchRow("Background mode", "Keep listening for Jarvis", "bg", false, JarvisService.alive) { on ->
                if (on) startJarvis(true) else stopService(Intent(this, JarvisService::class.java))
            }
        ), lp(12))

        p.addView(section("App Behaviour",
            switchRow("Greet me", "Say hello after I say Jarvis", "greet", true),
            switchRow("Silent listening", "Offline and silent, but less accurate", "silent", false),
            switchRow("Reboot reminder", "Notify me to start Jarvis after the phone restarts", "boot", false),
            infoRow("Battery optimization", "Allow background activity") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        ), lp(12))

        p.addView(section("About", infoRow("Version", "7.0"), infoRow("Built with", "Claude")), lp(12))

        p.addView(tv("Stop Jarvis", 16f, RED, true).apply {
            gravity = Gravity.CENTER
            background = bg(Color.parseColor("#1A0A10"), 14, RED)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                stopService(Intent(this@MainActivity, JarvisService::class.java))
                Toast.makeText(this@MainActivity, "Jarvis stopped", Toast.LENGTH_SHORT).show()
            }
        }, lp(16))
        return scroll(p)
    }

    // ---------- starting Jarvis ----------
    private fun perms(): List<String> {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        return need
    }

    private fun startJarvis(ask: Boolean) {
        if (ask) {
            val missing = perms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) {
                requestPermissions(missing.toTypedArray(), 1)
                return
            }
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Jarvis needs the microphone permission.", Toast.LENGTH_LONG).show()
            return
        }
        stopService(Intent(this, JarvisService::class.java))
        startForegroundService(Intent(this, JarvisService::class.java))
        if (!Answers.hasKey(this)) Toast.makeText(this, "Add a free Gemini key in Settings so Jarvis can chat.", Toast.LENGTH_LONG).show()
        ui.postDelayed({ refreshHome() }, 700)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        startJarvis(false)
    }
}
