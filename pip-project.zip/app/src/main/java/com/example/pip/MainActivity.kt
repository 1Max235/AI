package com.example.pip

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var claudeField: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        info = TextView(this).apply {
            textSize = 17f
            text = "1. Tap Start Jarvis and allow the permissions.\n2. Tap the two permission buttons below.\n\nThen say a command with the wake word, like: Jarvis open WhatsApp.\nOr say just Jarvis, wait for the beep, and then speak.\n\nExamples: call mom, navigate to the airport, set alarm for 7:30 am, flashlight on, search for pizza, who is the president of France.\n\nThe Claude API key is optional. Without it, answers come from Wikipedia."
        }
        claudeField = EditText(this).apply {
            hint = "Claude API key (optional)"
            setText(getSharedPreferences("pip", MODE_PRIVATE).getString("claude", ""))
        }
        col.addView(info)
        col.addView(claudeField)
        col.addView(btn("Start Jarvis") { start(true) })
        col.addView(btn("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Let Jarvis run in background") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Stop Jarvis") {
            stopService(Intent(this, JarvisService::class.java))
            info.text = "Jarvis stopped."
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun start(ask: Boolean) {
        getSharedPreferences("pip", MODE_PRIVATE).edit().putString("claude", claudeField.text.toString().trim()).apply()
        if (ask) {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) {
                requestPermissions(missing.toTypedArray(), 1)
                return
            }
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            info.text = "Jarvis needs the microphone permission."
            return
        }
        stopService(Intent(this, JarvisService::class.java))
        startForegroundService(Intent(this, JarvisService::class.java))
        info.text = "Jarvis is running. Say: Jarvis, open WhatsApp."
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        start(false)
    }
}
