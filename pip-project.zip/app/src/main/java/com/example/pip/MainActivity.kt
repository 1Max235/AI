package com.example.pip

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }
        log = TextView(this).apply {
            textSize = 18f
            text = "Tap Speak and say a command.\n\nTry:\nopen YouTube\ncall 555 0123\nset alarm for 7:30 am\nset timer for 5 minutes\nflashlight on\nvolume up\nWi-Fi settings\nsearch cute cats\nwhat time is it"
        }
        val btn = Button(this).apply {
            text = "Speak"
            textSize = 22f
            setOnClickListener { listen() }
        }
        root.addView(log, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn, LinearLayout.LayoutParams(-1, 200))
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    private fun show(msg: String) { log.text = msg }

    private fun say(msg: String) {
        show("Pip: $msg")
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "pip")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this phone.")
            return
        }
        tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    handle(t)
                }
                override fun onError(e: Int) { say("I did not catch that.") }
                override fun onReadyForSpeech(p: Bundle?) { show("Listening...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        recognizer?.startListening(i)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) listen()
    }

    private fun handle(raw: String) {
        val t = raw.lowercase(Locale.getDefault()).trim()
        show("You: $raw")
        try {
            when {
                t.contains("wifi") || t.contains("wi-fi") -> openSettings(Settings.ACTION_WIFI_SETTINGS, "Opening Wi-Fi settings")
                t.contains("bluetooth") -> openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Opening Bluetooth settings")
                t.startsWith("open ") -> openApp(t.removePrefix("open ").trim())
                t.startsWith("call ") -> dial(t.removePrefix("call ").trim())
                t.startsWith("search ") -> web(t.removePrefix("search ").trim())
                t.contains("timer") -> setTimer(t)
                t.contains("alarm") -> setAlarm(t)
                t.contains("flashlight") || t.contains("torch") -> torch(!t.contains("off"))
                t.contains("volume up") -> volume(AudioManager.ADJUST_RAISE, "Volume up")
                t.contains("volume down") -> volume(AudioManager.ADJUST_LOWER, "Volume down")
                t.contains("time") -> say("It is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
                else -> say("I do not know that command yet.")
            }
        } catch (e: ActivityNotFoundException) {
            say("Your phone cannot do that.")
        } catch (e: Exception) {
            say("That did not work.")
        }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(name)
        }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (match == null || launch == null) {
            say("I could not find an app called $name.")
            return
        }
        startActivity(launch)
        say("Opening " + match.loadLabel(pm))
    }

    private fun dial(what: String) {
        val number = what.filter { it.isDigit() || it == '+' }
        if (number.isEmpty()) {
            say("Say a phone number after call.")
            return
        }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        say("Dialing $number")
    }

    private fun web(q: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        say("Searching for $q")
    }

    private fun setTimer(t: String) {
        val m = Regex("(\\d+)\\s*(second|minute|hour)").find(t)
        if (m == null) {
            say("Say how long, like set timer for 5 minutes.")
            return
        }
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = when (unit) { "hour" -> n * 3600; "minute" -> n * 60; else -> n }
        startActivity(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        say("Timer set for $n $unit" + if (n == 1) "" else "s")
    }

    private fun setAlarm(t: String) {
        val m = Regex("""(\d{1,2})(?:[: .](\d{2}))?\s*([ap])?\.?m?""").find(t)
        if (m == null) {
            say("Say a time, like set alarm for 7:30 am.")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toIntOrNull() ?: 0
        val ap = m.groupValues[3]
        if (ap == "p" && hour < 12) hour += 12
        if (ap == "a" && hour == 12) hour = 0
        startActivity(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        say("Alarm set for %d:%02d".format(hour, minute))
    }

    private fun torch(on: Boolean) {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            say("This phone has no flashlight.")
            return
        }
        cm.setTorchMode(id, on)
        say(if (on) "Flashlight on" else "Flashlight off")
    }

    private fun volume(dir: Int, msg: String) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        say(msg)
    }

    private fun openSettings(action: String, msg: String) {
        startActivity(Intent(action))
        say(msg)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
