package com.example.pip

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var geminiField: EditText
    private lateinit var claudeField: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("pip", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        info = TextView(this).apply {
            textSize = 16f
            text = "Jarvis setup, in order:\n1. Paste a free Gemini key (aistudio.google.com/apikey).\n2. Tap Open app settings, open the 3-dot menu and choose Allow restricted settings (if shown).\n3. Tap Turn on phone control and enable Jarvis phone control.\n4. Tap Allow display over other apps and turn it on.\n5. Tap Let Jarvis run in background.\n6. Tap Start Jarvis, allow permissions, and wait for the one-time 40 MB speech model download.\n\nThen say: Jarvis (beep) open WhatsApp. After a chat answer, reply without saying Jarvis."
        }
        geminiField = EditText(this).apply {
            hint = "Gemini API key (free)"
            setText(prefs.getString("gemini", ""))
        }
        claudeField = EditText(this).apply {
            hint = "Claude API key (optional)"
            setText(prefs.getString("claude", ""))
        }
        col.addView(info)
        col.addView(geminiField)
        col.addView(claudeField)
        col.addView(btn("Open app settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Turn on phone control") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Let Jarvis run in background") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Start Jarvis") { start(true) })
        col.addView(btn("Stop Jarvis") {
            stopService(Intent(this, JarvisService::class.java))
            info.text = "Jarvis stopped."
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun start(ask: Boolean) {
        getSharedPreferences("pip", MODE_PRIVATE).edit()
            .putString("gemini", geminiField.text.toString().trim())
            .putString("claude", claudeField.text.toString().trim())
            .apply()
        if (ask) {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) {
                requestPermissions(missing.toTypedArray(), 1)
                return
            }
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            info.text = "Jarvis needs the microphone permission."
            return
        }
        stopService(Intent(this, JarvisService::class.java))
        startForegroundService(Intent(this, JarvisService::class.java))
        val todo = mutableListOf<String>()
        if (!Settings.canDrawOverlays(this)) todo.add("Allow display over other apps")
        if (JarvisAccessibility.instance == null) todo.add("Turn on phone control")
        if (!Answers.hasKey(this)) todo.add("Add a free Gemini key")
        info.text = "Jarvis is running. The first start downloads a 40 MB speech model, so wait for the notification to say Listening for Jarvis." +
            if (todo.isEmpty()) "" else "\n\nStill to do: " + todo.joinToString(", ") + ". Then tap Start Jarvis again."
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        start(false)
    }
}
