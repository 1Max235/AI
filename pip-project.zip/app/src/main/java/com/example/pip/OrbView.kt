package com.example.pip

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

class OrbView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f
        p.shader = null
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val t = (phase + i / 3f) % 1f
            p.strokeWidth = r * 0.012f + 1f
            p.color = Color.argb((110 * (1 - t)).toInt(), 54, 194, 255)
            c.drawCircle(cx, cy, r * (0.55f + 0.45f * t), p)
        }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 0.55f, intArrayOf(0xFF123766.toInt(), 0xFF071226.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.5f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.04f
        p.color = 0xFF36C2FF.toInt()
        c.drawCircle(cx, cy, r * 0.5f, p)
        // microphone icon
        val w = r * 0.1f
        val h = r * 0.24f
        p.style = Paint.Style.FILL
        c.drawRoundRect(cx - w, cy - h, cx + w, cy + h * 0.3f, w, w, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.03f
        p.strokeCap = Paint.Cap.ROUND
        c.drawArc(cx - w * 1.9f, cy - h * 0.6f, cx + w * 1.9f, cy + h * 0.85f, 20f, 140f, false, p)
        c.drawLine(cx, cy + h * 0.85f, cx, cy + h * 1.15f, p)
    }
}
