package com.example.pip

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Date

object Answers {
    private const val PERSONA = """You are Jarvis, a friendly, witty voice assistant living on the user's Android phone. Talk casually like a friend and keep spoken replies to one to three short sentences. No markdown, lists or emojis.
Always reply with ONE JSON object and nothing else: {"say":"what to speak aloud","actions":[...]}
Each action is {"name":"...","args":{...}}. Available actions:
open_app{app}; call{who (contact name or number)}; sms{to,text}; whatsapp{to,text}; alarm{hour 0-23,minute}; timer{seconds}; navigate{place}; web_search{query}; play_music{query}; media{control: play|pause|next|previous|stop}; flashlight{on: true|false}; volume{direction: up|down}; settings{page: wifi|bluetooth}; phone{action: home|back|recents|notifications|quick_settings|lock|screenshot|scroll_up|scroll_down}; tap{text on screen}; remember{fact}; clear_memory{}.
Use actions only when the user asks for something to be done; otherwise use an empty actions list. For messages you only draft them and the user taps send. Use web search for current facts like news, weather and scores. Use the device context below when relevant."""

    private val history = ArrayList<Pair<String, String>>()

    private fun key(ctx: Context, name: String) =
        ctx.getSharedPreferences("pip", Context.MODE_PRIVATE).getString(name, "")?.trim() ?: ""

    fun hasKey(ctx: Context) = key(ctx, "gemini").isNotEmpty() || key(ctx, "claude").isNotEmpty()

    fun addFact(ctx: Context, fact: String) {
        val p = ctx.getSharedPreferences("pip", Context.MODE_PRIVATE)
        val old = p.getString("facts", "") ?: ""
        p.edit().putString("facts", (old + "\n" + fact).trim().takeLast(3000)).apply()
    }

    fun clearFacts(ctx: Context) {
        ctx.getSharedPreferences("pip", Context.MODE_PRIVATE).edit().remove("facts").apply()
    }

    private fun system(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val facts = ctx.getSharedPreferences("pip", Context.MODE_PRIVATE).getString("facts", "") ?: ""
        return PERSONA + "\n\nDevice context: now=" + Date() +
            ", battery=" + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + "%, charging=" + bm.isCharging +
            "\nThings the user asked you to remember:\n" + facts.ifBlank { "(nothing yet)" }
    }

    fun ask(ctx: Context, q: String, done: (String) -> Unit) {
        val g = key(ctx, "gemini")
        val c = key(ctx, "claude")
        val sys = system(ctx)
        Thread {
            var ans: String? = null
            if (g.isNotEmpty()) ans = try { gemini(g, sys, q) } catch (e: Exception) { null }
            if (ans.isNullOrBlank() && c.isNotEmpty()) ans = try { claude(c, sys, q) } catch (e: Exception) { null }
            val ai = !ans.isNullOrBlank()
            if (!ai) ans = try { wiki(q) } catch (e: Exception) { null }
            val out = if (!ans.isNullOrBlank()) ans
                else if (g.isEmpty() && c.isEmpty()) "I could not find that. To chat with me properly, add a free Gemini key in the app."
                else "My brain did not answer. Check your internet connection and your key."
            if (ai) synchronized(history) {
                history.add("user" to q)
                history.add("model" to out)
                while (history.size > 12) { history.removeAt(0); history.removeAt(0) }
            }
            done(out)
        }.start()
    }

    private fun http(url: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "JarvisApp/1.0")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    private fun gemini(key: String, sys: String, q: String): String {
        val contents = JSONArray()
        synchronized(history) {
            history.forEach { (r, t) ->
                contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q))))
        fun call(withSearch: Boolean): String {
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents)
            if (withSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val res = JSONObject(http(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent",
                body.toString(), mapOf("x-goog-api-key" to key, "content-type" to "application/json")
            ))
            val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString()
        }
        var raw = try { call(true) } catch (e: Exception) { "" }
        if (raw.isBlank()) raw = call(false)
        return raw.trim()
    }

    private fun claude(key: String, sys: String, q: String): String {
        val msgs = JSONArray()
        synchronized(history) {
            history.forEach { (r, t) ->
                msgs.put(JSONObject().put("role", if (r == "model") "assistant" else "user").put("content", t))
            }
        }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 600)
            .put("system", sys)
            .put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 2)))
            .put("messages", msgs)
        val res = JSONObject(http(
            "https://api.anthropic.com/v1/messages", body.toString(),
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json")
        ))
        val content = res.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun wiki(q: String): String {
        val cleaned = q.lowercase().replace(
            Regex("^(what is|what are|what was|who is|who was|who are|tell me about|look up|define|explain|where is|when was|when is)\\s+(a |an |the )?"), ""
        ).trim()
        val enc = URLEncoder.encode(cleaned, "UTF-8")
        val s = JSONObject(http("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=$enc"))
        val hits = s.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) return ""
        val title = hits.getJSONObject(0).getString("title")
        val page = JSONObject(http("https://en.wikipedia.org/api/rest_v1/page/summary/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8")))
        val extract = page.optString("extract")
        if (extract.isBlank()) return ""
        val two = extract.split(". ").take(2).joinToString(". ")
        return if (two.endsWith(".")) two else "$two."
    }
}
