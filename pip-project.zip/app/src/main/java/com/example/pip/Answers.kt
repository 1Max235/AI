package com.example.pip

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Answers {
    fun ask(ctx: Context, question: String, done: (String) -> Unit) {
        val key = ctx.getSharedPreferences("pip", Context.MODE_PRIVATE).getString("claude", "") ?: ""
        Thread {
            var ans: String? = null
            if (key.isNotEmpty()) ans = try { claude(key, question) } catch (e: Exception) { null }
            if (ans.isNullOrBlank()) ans = try { wiki(question) } catch (e: Exception) { null }
            done(if (ans.isNullOrBlank()) "I could not find an answer. Check your internet connection." else ans)
        }.start()
    }

    private fun http(url: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "JarvisApp/1.0")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    private fun claude(key: String, q: String): String {
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 400)
            .put("system", "You are Jarvis, a voice assistant. Answer in one to three short spoken sentences. Plain text only, no markdown, no lists. Use web search for current facts.")
            .put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 2)))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
        val res = JSONObject(http(
            "https://api.anthropic.com/v1/messages", body.toString(),
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json")
        ))
        val content = res.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString().replace(Regex("[*#_`]"), "").trim()
    }

    private fun wiki(q: String): String {
        val clean = q.lowercase().replace(
            Regex("^(what is|what are|what was|who is|who was|who are|tell me about|look up|define|explain|where is|when was|when is)\\s+(a |an |the )?"), ""
        ).trim()
        val enc = URLEncoder.encode(clean, "UTF-8")
        val s = JSONObject(http("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=$enc"))
        val hits = s.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) return ""
        val title = hits.getJSONObject(0).getString("title")
        val page = JSONObject(http("https://en.wikipedia.org/api/rest_v1/page/summary/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8")))
        val extract = page.optString("extract")
        if (extract.isBlank()) return ""
        val two = extract.split(". ").take(2).joinToString(". ")
        return if (two.endsWith(".")) two else "$two."
    }
}
