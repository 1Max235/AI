package com.example.pip

import android.app.Application

class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                ActivityLog.err(this, "Crash: " + e + " at " + (e.stackTrace.firstOrNull()?.toString() ?: ""))
            } catch (x: Exception) {}
            old?.uncaughtException(t, e)
        }
    }
}
