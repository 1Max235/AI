package com.example.pip

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class Commands(private val ctx: Context, private val say: (String) -> Unit, private val onChat: () -> Unit = {}) {
    private val ui = Handler(Looper.getMainLooper())
    private var quiet = false
    private val starts = listOf("what ", "who ", "when ", "where ", "why ", "how ", "which ", "is ", "are ", "does ", "do ", "can ", "tell me", "define ", "explain ", "look up ")
    private val aliases = mapOf("insta" to "instagram", "ig" to "instagram", "fb" to "facebook", "yt" to "youtube", "texts" to "messages")

    // ---------- entry point for spoken text ----------
    fun handle(raw: String) {
        val t = raw.lowercase(Locale.getDefault()).replace("please", "").trim()
        val st = if (Answers.hasKey(ctx)) null else smallTalk(t)
        try {
            when {
                st != null -> say(st)
                listOf("what time is it", "what's the time", "what is the time", "current time", "tell me the time").any { t.contains(it) } ->
                    say("It is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
                t.contains("go home") || t.contains("home screen") -> phone("home")
                t.contains("go back") -> phone("back")
                t.contains("screenshot") -> phone("screenshot")
                t.contains("scroll down") -> phone("scroll_down")
                t.contains("scroll up") -> phone("scroll_up")
                t.contains("lock") && t.contains("phone") -> phone("lock")
                t.startsWith("tap ") || t.startsWith("click ") -> tap(t.substringAfter(' ').trim())
                t.contains("next song") || t.contains("next track") -> media("next")
                t.contains("previous song") || t.contains("previous track") -> media("previous")
                t == "pause" || t.contains("pause the music") || t.contains("pause music") -> media("pause")
                t == "resume" || t.contains("resume music") -> media("play")
                t.startsWith("play ") -> playMusic(t.removePrefix("play ").trim())
                starts.any { t.startsWith(it) } -> answer(t)
                t.contains("wifi") || t.contains("wi-fi") -> settings("wifi")
                t.contains("bluetooth") -> settings("bluetooth")
                t.startsWith("open ") -> openApp(t.removePrefix("open ").trim())
                t.startsWith("launch ") -> openApp(t.removePrefix("launch ").trim())
                t.startsWith("call ") -> dial(t.removePrefix("call ").trim())
                t.startsWith("navigate to ") -> navigate(t.removePrefix("navigate to ").trim())
                t.startsWith("search for ") -> web(t.removePrefix("search for ").trim())
                t.startsWith("search ") -> web(t.removePrefix("search ").trim())
                t.startsWith("google ") -> web(t.removePrefix("google ").trim())
                t.contains("timer") -> setTimer(t)
                t.contains("alarm") -> setAlarm(t)
                t.contains("flashlight") || t.contains("torch") -> torch(!t.contains("off"))
                t.contains("volume up") -> volume("up")
                t.contains("volume down") -> volume("down")
                else -> answer(t)
            }
        } catch (e: ActivityNotFoundException) {
            say("Your phone cannot do that.")
        } catch (e: Exception) {
            say("That did not work.")
        }
    }

    // ---------- AI brain ----------
    private fun answer(q: String) {
        Answers.ask(ctx, q) { raw ->
            val j = parse(raw)
            val speech = if (j == null) raw else j.optString("say").ifBlank { "Done." }
            val acts = j?.optJSONArray("actions")
            val n = acts?.length() ?: 0
            for (i in 0 until n) {
                val a = acts!!.optJSONObject(i) ?: continue
                ui.postDelayed({ runAction(a) }, 700L * i)
            }
            say(speech)
            if (n == 0) onChat()
        }
    }

    private fun parse(raw: String): JSONObject? = try {
        JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
    } catch (e: Exception) { null }

    private fun runAction(a: JSONObject) {
        val g = a.optJSONObject("args") ?: JSONObject()
        quiet = true
        try {
            when (a.optString("name")) {
                "open_app" -> openApp(g.optString("app").lowercase(Locale.getDefault()))
                "call" -> dial(g.optString("who"))
                "sms" -> sms(g.optString("to"), g.optString("text"))
                "whatsapp" -> whatsapp(g.optString("to"), g.optString("text"))
                "alarm" -> alarmAt(g.optInt("hour"), g.optInt("minute"))
                "timer" -> timerSecs(g.optInt("seconds"))
                "navigate" -> navigate(g.optString("place"))
                "web_search" -> web(g.optString("query"))
                "play_music" -> playMusic(g.optString("query"))
                "media" -> media(g.optString("control"))
                "flashlight" -> torch(g.optBoolean("on", true))
                "volume" -> volume(g.optString("direction"))
                "settings" -> settings(g.optString("page"))
                "phone" -> phone(g.optString("action"))
                "tap" -> tap(g.optString("text"))
                "remember" -> Answers.addFact(ctx, g.optString("fact"))
                "clear_memory" -> Answers.clearFacts(ctx)
            }
        } catch (e: Exception) {
            say("That did not work.")
        } finally {
            quiet = false
        }
    }

    // ---------- helpers ----------
    private fun out(m: String) { if (!quiet) say(m) }

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun smallTalk(t: String): String? = when {
        Regex("^(hi|hello|hey)\\b").containsMatchIn(t) -> "Hello! How can I help?"
        t.contains("how are you") -> "I am doing great, thanks for asking. How are you?"
        t.contains("thank") -> "You are welcome."
        t.contains("your name") || t.contains("who are you") -> "I am Jarvis, your phone assistant."
        t.contains("joke") -> "Why did the phone go to school? It wanted to be smarter."
        t.contains("good morning") -> "Good morning! Hope you have a great day."
        t.contains("good night") -> "Good night. Sleep well."
        else -> null
    }

    private fun norm(s: String) = s.lowercase(Locale.getDefault()).filter { it.isLetterOrDigit() }

    private fun dist(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun openApp(name: String) {
        val want = norm(aliases[name] ?: name)
        if (want.isEmpty()) {
            say("Which app?")
            return
        }
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            val label = it.loadLabel(pm).toString()
            Triple(norm(label), label, it.activityInfo.packageName)
        }
        val hit = apps.firstOrNull { it.first == want }
            ?: apps.firstOrNull { it.first.contains(want) || (it.first.length >= 3 && want.contains(it.first)) }
            ?: apps.filter { dist(it.first, want) <= maxOf(1, want.length / 4) }.minByOrNull { dist(it.first, want) }
        val launch = hit?.let { pm.getLaunchIntentForPackage(it.third) }
        if (hit == null || launch == null) {
            val near = apps.sortedBy { dist(it.first, want) }.take(2).joinToString(" or ") { it.second }
            say("I could not find $name." + if (near.isNotEmpty()) " Did you mean $near?" else "")
            return
        }
        go(launch)
        out("Opening " + hit.second)
    }

    private fun findNumber(name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun numberFor(who: String): String {
        val digits = who.filter { it.isDigit() || it == '+' }
        return if (digits.length >= 3) digits else (findNumber(who) ?: "")
    }

    private fun dial(who: String) {
        val number = numberFor(who)
        if (number.isEmpty()) {
            say("I could not find $who.")
            return
        }
        val canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
        out("Calling $who")
    }

    private fun sms(to: String, text: String) {
        val number = numberFor(to)
        if (number.isEmpty()) {
            say("I could not find $to.")
            return
        }
        go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text))
        out("Message ready. Tap send.")
    }

    private fun whatsapp(to: String, text: String) {
        val number = numberFor(to).filter { it.isDigit() }
        if (number.isEmpty()) {
            say("I could not find $to.")
            return
        }
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=" + Uri.encode(text))))
        out("WhatsApp message ready. Tap send.")
    }

    private fun navigate(place: String) {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
        out("Navigating to $place")
    }

    private fun web(q: String) {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        out("Searching for $q")
    }

    private fun playMusic(q: String) {
        try {
            go(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (e: ActivityNotFoundException) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        }
        out("Playing $q")
    }

    private fun media(c: String) {
        val code = when (c) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        out("OK")
    }

    private fun setTimer(t: String) {
        val m = Regex("(\\d+)\\s*(second|minute|hour)").find(t)
        if (m == null) {
            say("Say how long, like set timer for 5 minutes.")
            return
        }
        val n = m.groupValues[1].toInt()
        timerSecs(when (m.groupValues[2]) { "hour" -> n * 3600; "minute" -> n * 60; else -> n })
    }

    private fun timerSecs(secs: Int) {
        if (secs <= 0) {
            say("How long should the timer be?")
            return
        }
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        out("Timer set")
    }

    private fun setAlarm(t: String) {
        val m = Regex("""(\d{1,2})(?:[: .](\d{2}))?\s*([ap])?\.?m?""").find(t)
        if (m == null) {
            say("Say a time, like set alarm for 7:30 am.")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toIntOrNull() ?: 0
        val ap = m.groupValues[3]
        if (ap == "p" && hour < 12) hour += 12
        if (ap == "a" && hour == 12) hour = 0
        alarmAt(hour, minute)
    }

    private fun alarmAt(hour: Int, minute: Int) {
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        out("Alarm set for %d:%02d".format(hour, minute))
    }

    private fun torch(on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            say("This phone has no flashlight.")
            return
        }
        cm.setTorchMode(id, on)
        out(if (on) "Flashlight on" else "Flashlight off")
    }

    private fun volume(direction: String) {
        val dir = if (direction == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        out("Volume $direction")
    }

    private fun settings(page: String) {
        go(Intent(if (page == "bluetooth") Settings.ACTION_BLUETOOTH_SETTINGS else Settings.ACTION_WIFI_SETTINGS))
        out("Opening settings")
    }

    private fun phone(action: String) {
        val a = JarvisAccessibility.instance
        if (a == null) {
            say("Turn on Jarvis phone control in Accessibility settings first.")
            return
        }
        val ok = when (action) {
            "home" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "back" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "recents" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "lock" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "screenshot" -> Build.VERSION.SDK_INT >= 28 && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scroll_down" -> a.scroll(true)
            "scroll_up" -> a.scroll(false)
            else -> false
        }
        if (!ok) say("That did not work.")
    }

    private fun tap(text: String) {
        val a = JarvisAccessibility.instance
        if (a == null) {
            say("Turn on Jarvis phone control in Accessibility settings first.")
            return
        }
        if (!a.tapText(text)) say("I could not find $text on the screen.")
    }
}
