package com.example.pip

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class Commands(private val ctx: Context, private val say: (String) -> Unit) {

    private val starts = listOf("what ", "who ", "when ", "where ", "why ", "how ", "which ", "is ", "are ", "does ", "do ", "can ", "tell me", "define ", "explain ", "look up ")
    private val aliases = mapOf("insta" to "instagram", "ig" to "instagram", "fb" to "facebook", "yt" to "youtube", "texts" to "messages")

    fun handle(raw: String) {
        val t = raw.lowercase(Locale.getDefault()).replace("please", "").trim()
        try {
            when {
                listOf("what time is it", "what's the time", "what is the time", "current time", "tell me the time").any { t.contains(it) } ->
                    say("It is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
                starts.any { t.startsWith(it) } -> answer(t)
                t.contains("wifi") || t.contains("wi-fi") -> settings(Settings.ACTION_WIFI_SETTINGS, "Opening Wi-Fi settings")
                t.contains("bluetooth") -> settings(Settings.ACTION_BLUETOOTH_SETTINGS, "Opening Bluetooth settings")
                t.startsWith("open ") -> openApp(t.removePrefix("open ").trim())
                t.startsWith("launch ") -> openApp(t.removePrefix("launch ").trim())
                t.startsWith("call ") -> dial(t.removePrefix("call ").trim())
                t.startsWith("navigate to ") -> navigate(t.removePrefix("navigate to ").trim())
                t.startsWith("search for ") -> web(t.removePrefix("search for ").trim())
                t.startsWith("search ") -> web(t.removePrefix("search ").trim())
                t.startsWith("google ") -> web(t.removePrefix("google ").trim())
                t.contains("timer") -> setTimer(t)
                t.contains("alarm") -> setAlarm(t)
                t.contains("flashlight") || t.contains("torch") -> torch(!t.contains("off"))
                t.contains("volume up") -> volume(AudioManager.ADJUST_RAISE, "Volume up")
                t.contains("volume down") -> volume(AudioManager.ADJUST_LOWER, "Volume down")
                else -> answer(t)
            }
        } catch (e: ActivityNotFoundException) {
            say("Your phone cannot do that.")
        } catch (e: Exception) {
            say("That did not work.")
        }
    }

    private fun answer(q: String) {
        say("One moment.")
        Answers.ask(ctx, q) { say(it) }
    }

    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun settings(action: String, msg: String) {
        go(Intent(action))
        say(msg)
    }

    private fun norm(s: String) = s.lowercase(Locale.getDefault()).filter { it.isLetterOrDigit() }

    private fun dist(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun openApp(name: String) {
        val want = norm(aliases[name] ?: name)
        if (want.isEmpty()) {
            say("Which app?")
            return
        }
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            val label = it.loadLabel(pm).toString()
            Triple(norm(label), label, it.activityInfo.packageName)
        }
        val hit = apps.firstOrNull { it.first == want }
            ?: apps.firstOrNull { it.first.contains(want) || (it.first.length >= 3 && want.contains(it.first)) }
            ?: apps.filter { dist(it.first, want) <= maxOf(1, want.length / 4) }.minByOrNull { dist(it.first, want) }
        val launch = hit?.let { pm.getLaunchIntentForPackage(it.third) }
        if (hit == null || launch == null) {
            val near = apps.sortedBy { dist(it.first, want) }.take(2).joinToString(" or ") { it.second }
            say("I could not find $name." + if (near.isNotEmpty()) " Did you mean $near?" else "")
            return
        }
        go(launch)
        say("Opening " + hit.second)
    }

    private fun findNumber(name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun dial(what: String) {
        var number = what.filter { it.isDigit() || it == '+' }
        if (number.length < 3) number = findNumber(what) ?: ""
        if (number.isEmpty()) {
            say("I could not find $what.")
            return
        }
        val canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        go(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
        say("Calling $what")
    }

    private fun navigate(place: String) {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
        say("Navigating to $place")
    }

    private fun web(q: String) {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        say("Searching for $q")
    }

    private fun setTimer(t: String) {
        val m = Regex("(\\d+)\\s*(second|minute|hour)").find(t)
        if (m == null) {
            say("Say how long, like set timer for 5 minutes.")
            return
        }
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = when (unit) { "hour" -> n * 3600; "minute" -> n * 60; else -> n }
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        say("Timer set for $n $unit" + if (n == 1) "" else "s")
    }

    private fun setAlarm(t: String) {
        val m = Regex("""(\d{1,2})(?:[: .](\d{2}))?\s*([ap])?\.?m?""").find(t)
        if (m == null) {
            say("Say a time, like set alarm for 7:30 am.")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toIntOrNull() ?: 0
        val ap = m.groupValues[3]
        if (ap == "p" && hour < 12) hour += 12
        if (ap == "a" && hour == 12) hour = 0
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        say("Alarm set for %d:%02d".format(hour, minute))
    }

    private fun torch(on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            say("This phone has no flashlight.")
            return
        }
        cm.setTorchMode(id, on)
        say(if (on) "Flashlight on" else "Flashlight off")
    }

    private fun volume(dir: Int, msg: String) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        say(msg)
    }
}
