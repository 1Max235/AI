package com.example.pip

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.util.zip.ZipInputStream
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service() {
    companion object {
        @Volatile var alive = false
        @Volatile var statusText = ""
        const val ACTION_LISTEN = "com.example.pip.LISTEN"
    }

    private val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private val candidates = listOf("jarvis", "jervis", "jarvas")
    private val fallbackWords = listOf("jarvis", "jarvas", "jervis", "jarvice")

    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private lateinit var commands: Commands
    private var recognizer: SpeechRecognizer? = null
    private var overlay: View? = null
    private var model: Model? = null
    private var wakeSvc: SpeechService? = null
    private var wakeWords: List<String> = emptyList()
    private var useFallback = false
    private var waking = false
    private var running = true
    @Volatile private var ready = false
    private var offlineDone = false
    @Volatile private var chatFollowUp = false
    @Volatile private var afterSpeech = 0
    private val watch = Runnable { resume() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_LISTEN) {
            main.post {
                if (ready) {
                    main.removeCallbacks(watch)
                    stopWake()
                    recognizer?.destroy()
                    waking = true
                    greet()
                }
            }
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        alive = true
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts.language = loc()
                pickVoice()
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { finished() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { finished() }
                })
            }
        }
        commands = Commands(this, { msg -> speak(msg) }, { chatFollowUp = true })

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = note("Getting ready...")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        addOverlay()
        prepare()
    }

    private fun note(text: String): Notification =
        Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun status(text: String) {
        statusText = text
        getSystemService(NotificationManager::class.java).notify(1, note(text))
    }

    // Tiny invisible window so Android allows opening apps from the background.
    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val v = View(this)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {}
    }

    // ---------- offline wake word model ----------
    private fun prepare() {
        Thread {
            try {
                val dir = File(filesDir, "vosk-model")
                if (!File(dir, "am").exists()) {
                    main.post { status("Downloading offline speech model (about 40 MB)...") }
                    download(dir)
                }
                val m = Model(dir.path)
                val vocab = try {
                    File(dir, "graph/words.txt").useLines { l -> l.map { it.substringBefore(' ') }.toHashSet() }
                } catch (e: Exception) { null }
                wakeWords = candidates.filter { vocab == null || it in vocab }
                if (wakeWords.isEmpty()) throw RuntimeException("wake word not in model")
                model = m
            } catch (e: Exception) {
                useFallback = true
                ActivityLog.err(this, "Offline wake word unavailable: $e")
            }
            main.post {
                ready = true
                status(if (useFallback) "Listening for Jarvis (basic mode)" else "Listening for Jarvis")
                resume()
            }
        }.start()
    }

    private fun download(dir: File) {
        val zip = File(cacheDir, "model.zip")
        val c = URL(modelUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.inputStream.use { i -> zip.outputStream().use { o -> i.copyTo(o) } }
        dir.deleteRecursively()
        dir.mkdirs()
        ZipInputStream(zip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val rel = e.name.substringAfter('/')
                if (rel.isNotEmpty() && !rel.contains("..")) {
                    val f = File(dir, rel)
                    if (e.isDirectory) f.mkdirs()
                    else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> z.copyTo(o) }
                    }
                }
                e = z.nextEntry
            }
        }
        zip.delete()
    }

    // ---------- listening state machine ----------
    private fun resume() {
        if (!running) return
        main.removeCallbacks(watch)
        stopWake()
        recognizer?.destroy()
        recognizer = null
        waking = false
        if (useFallback || model == null) fallbackLoop() else startWake()
    }

    private fun startWake() {
        try {
            val grammar = wakeWords.joinToString(",", "[", ",\"[unk]\"]") { "\"$it\"" }
            val svc = SpeechService(Recognizer(model!!, 16000.0f, grammar), 16000.0f)
            wakeSvc = svc
            svc.startListening(object : VoskListener {
                override fun onPartialResult(h: String?) { heard(h) }
                override fun onResult(h: String?) { heard(h) }
                override fun onFinalResult(h: String?) { heard(h) }
                override fun onError(e: Exception?) {}
                override fun onTimeout() {}
            })
        } catch (e: Exception) {
            useFallback = true
            fallbackLoop()
        }
    }

    private fun heard(h: String?) {
        if (h == null || waking || wakeWords.none { h.contains(it) }) return
        waking = true
        main.post {
            stopWake()
            greet()
        }
    }

    private fun stopWake() {
        try { wakeSvc?.stop(); wakeSvc?.shutdown() } catch (e: Exception) {}
        wakeSvc = null
    }

    private fun recognize(done: (String?) -> Unit) {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    done(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.getDefault()))
                }
                override fun onError(e: Int) { done(null) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val tag = loc().toLanguageTag()
        recognizer?.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1800L)
                .putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1800L)
        )
    }

    private fun listenCommand() {
        val silent = getSharedPreferences("pip", MODE_PRIVATE).getBoolean("silent", false)
        if (silent && model != null && !useFallback) {
            offlineDone = false
            listenOffline()
        } else {
            recognize { t -> afterHeard(t ?: "") }
        }
    }

    private fun afterHeard(raw: String) {
        var s = raw
        fallbackWords.forEach { s = s.replace(it, "") }
        s = s.trim(',', '.', ' ')
        if (s.isEmpty()) main.post { resume() } else { status("Heard: $s"); dispatch(s) }
    }

    // Silent mode: the offline Vosk model listens for the command, so Google's listening sound never plays.
    private fun listenOffline() {
        try {
            val svc = SpeechService(Recognizer(model!!, 16000.0f), 16000.0f)
            wakeSvc = svc
            svc.startListening(object : VoskListener {
                override fun onPartialResult(h: String?) {}
                override fun onResult(h: String?) { gotOffline(h) }
                override fun onFinalResult(h: String?) { gotOffline(h) }
                override fun onError(e: Exception?) { main.post { resume() } }
                override fun onTimeout() { main.post { resume() } }
            }, 9000)
        } catch (e: Exception) {
            main.post { resume() }
        }
    }

    private fun gotOffline(h: String?) {
        val t = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
        if (t.isBlank() || offlineDone) return
        offlineDone = true
        main.post { stopWake(); afterHeard(t) }
    }

    private fun fallbackLoop() {
        if (!running) return
        recognize { t ->
            val w = if (t == null) null else fallbackWords.firstOrNull { t.contains(it) }
            if (t == null || w == null) {
                main.postDelayed({ fallbackLoop() }, 300)
            } else {
                val cmd = t.substringAfter(w).trimStart(',', '.', ' ')
                if (cmd.isNotEmpty()) dispatch(cmd) else greet()
            }
        }
    }

    private fun dispatch(text: String) {
        ActivityLog.add(this, text)
        main.removeCallbacks(watch)
        main.postDelayed(watch, 40000)
        commands.handle(text)
    }

    private fun finished() {
        main.post {
            main.removeCallbacks(watch)
            val mode = if (chatFollowUp) 1 else afterSpeech
            chatFollowUp = false
            afterSpeech = 0
            when (mode) {
                2 -> main.postDelayed({ listenCommand() }, 250)
                1 -> main.postDelayed({ listenCommand() }, 400)
                else -> main.postDelayed({ resume() }, 300)
            }
        }
    }

    private fun loc(): Locale {
        val l = getSharedPreferences("pip", MODE_PRIVATE).getString("lang", "")?.trim() ?: ""
        return if (l.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(l)
    }

    private fun pickVoice() {
        try {
            val lang = tts.language?.language ?: return
            val best = tts.voices?.filter { it.locale.language == lang }?.maxByOrNull { it.quality }
            if (best != null) tts.voice = best
        } catch (e: Exception) {}
    }

    private fun speak(msg: String) {
        tts.setPitch(getSharedPreferences("pip", MODE_PRIVATE).getFloat("pitch", 1.0f))
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun greet() {
        val p = getSharedPreferences("pip", MODE_PRIVATE)
        main.removeCallbacks(watch)
        if (!p.getBoolean("greet", true)) {
            main.postDelayed({ listenCommand() }, 150)
            return
        }
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening"
        val nm = p.getString("name", "")?.trim().orEmpty()
        val who = if (nm.isEmpty()) "" else ", $nm"
        val lines = listOf(
            "Hey$who! What is on your mind today?",
            "$part$who! What can I do for you?",
            "Hi there$who! What is up?",
            "Yes? I am listening.",
            "Hey$who, how can I help?"
        )
        afterSpeech = 2
        main.postDelayed(watch, 15000)
        speak(lines.random())
    }

    override fun onDestroy() {
        running = false
        alive = false
        main.removeCallbacksAndMessages(null)
        stopWake()
        recognizer?.destroy()
        try { model?.close() } catch (e: Exception) {}
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (e: Exception) {}
        tts.shutdown()
        super.onDestroy()
    }
}
