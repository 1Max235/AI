package com.example.pip

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service() {
    companion object {
        @Volatile var alive = false
        @Volatile var statusText = ""
        const val ACTION_LISTEN = "com.example.pip.LISTEN"
    }

    private val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private val candidates = listOf("jarvis", "jervis", "jarvas")
    private val fallbackWords = listOf("jarvis", "jarvas", "jervis", "jarvice")

    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private lateinit var commands: Commands
    private var recognizer: SpeechRecognizer? = null
    private var overlay: View? = null
    private var model: Model? = null
    private var wakeRec: Recognizer? = null
    private var cmdRec: Recognizer? = null
    private var wakeSvc: SpeechService? = null
    private var wakeWords: List<String> = emptyList()
    private var useFallback = false
    private var waking = false
    private var running = true
    private var wakeFails = 0
    private var offlineDone = false
    private var state = "boot"
    private var stateSince = 0L
    @Volatile private var ready = false
    @Volatile private var ttsReady = false
    @Volatile private var replying = false
    @Volatile private var endConvo = false
    private val begin = Runnable { beginWake() }
    @Volatile private var chatFollowUp = false
    @Volatile private var afterSpeech = 0
    private val trailLines = ArrayDeque<String>()

    private val watch = Runnable { trail("watchdog fired while $state"); resume() }
    private val beat = object : Runnable {
        override fun run() {
            if (!running) return
            val age = System.currentTimeMillis() - stateSince
            if (ready) {
                if (state == "wake" && !useFallback && wakeSvc == null) { trail("heartbeat: wake listener missing"); resume() }
                else if (state != "wake" && age > 45000) { trail("heartbeat: stuck in $state"); resume() }
            }
            main.postDelayed(this, 8000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_LISTEN) {
            main.post {
                if (ready) {
                    main.removeCallbacks(watch)
                    stopWake()
                    recognizer?.destroy()
                    waking = true
                    greet()
                }
            }
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        alive = true
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts.language = ttsLoc()
                pickVoice()
                ttsReady = true
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { finished() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { finished() }
                })
            }
        }
        commands = Commands(this, { msg -> speak(msg) }, { chatFollowUp = true }, { endConvo = true })

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = note("Getting ready...")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        addOverlay()
        prepare()
    }

    private fun note(text: String): Notification =
        Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()

    private fun status(text: String) {
        statusText = text
        getSystemService(NotificationManager::class.java).notify(1, note(text))
    }

    private fun trail(m: String) {
        val line = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + " " + m
        synchronized(trailLines) {
            trailLines.addLast(line)
            while (trailLines.size > 14) trailLines.removeFirst()
            getSharedPreferences("pip", MODE_PRIVATE).edit().putString("trail", trailLines.joinToString("\n")).apply()
        }
    }

    private fun setState(s: String) {
        state = s
        stateSince = System.currentTimeMillis()
        trail("state: $s")
    }

    // Tiny invisible window so Android allows opening apps from the background.
    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val v = View(this)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {}
    }

    // ---------- offline wake word model ----------
    private fun prepare() {
        Thread {
            try {
                val dir = File(filesDir, "vosk-model")
                if (!File(dir, "am").exists()) {
                    main.post { status("Downloading offline speech model (about 40 MB)...") }
                    download(dir)
                }
                val m = Model(dir.path)
                val vocab = try {
                    File(dir, "graph/words.txt").useLines { l -> l.map { it.substringBefore(' ') }.toHashSet() }
                } catch (e: Exception) { null }
                wakeWords = candidates.filter { vocab == null || it in vocab }
                if (wakeWords.isEmpty()) throw RuntimeException("wake word not in model")
                val grammar = wakeWords.joinToString(",", "[", ",\"[unk]\"]") { "\"$it\"" }
                wakeRec = Recognizer(m, 16000.0f, grammar)
                model = m
                trail("model ready, wake words $wakeWords")
            } catch (e: Exception) {
                useFallback = true
                ActivityLog.err(this, "Offline wake word unavailable: $e")
                trail("model failed: $e")
            }
            main.post {
                ready = true
                status(if (useFallback) "Listening for Jarvis (basic mode)" else "Listening for Jarvis")
                startup()
                main.postDelayed(beat, 8000)
            }
        }.start()
    }

    private fun download(dir: File) {
        val zip = File(cacheDir, "model.zip")
        val c = URL(modelUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.inputStream.use { i -> zip.outputStream().use { o -> i.copyTo(o) } }
        dir.deleteRecursively()
        dir.mkdirs()
        ZipInputStream(zip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val rel = e.name.substringAfter('/')
                if (rel.isNotEmpty() && !rel.contains("..")) {
                    val f = File(dir, rel)
                    if (e.isDirectory) f.mkdirs()
                    else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> z.copyTo(o) }
                    }
                }
                e = z.nextEntry
            }
        }
        zip.delete()
    }

    // ---------- listening state machine ----------
    private fun resume() {
        if (!running) return
        main.removeCallbacks(watch)
        stopWake()
        val had = recognizer != null
        recognizer?.destroy()
        recognizer = null
        waking = false
        main.removeCallbacks(begin)
        main.postDelayed(begin, if (had) 900L else 50L)
    }

    private fun beginWake() {
        if (!running || waking) return
        stopWake()
        if (useFallback || wakeRec == null) fallbackLoop() else startWake()
    }

    private fun startWake() {
        val rec = wakeRec
        if (rec == null) { useFallback = true; fallbackLoop(); return }
        try {
            val svc = SpeechService(rec, 16000.0f)
            val t0 = System.currentTimeMillis()
            val ok = svc.startListening(object : VoskListener {
                override fun onPartialResult(h: String?) { heard(h) }
                override fun onResult(h: String?) { heard(h) }
                override fun onFinalResult(h: String?) { heard(h) }
                override fun onError(e: Exception?) {
                    trail("vosk error: $e")
                    if (wakeSvc === svc) {
                        wakeSvc = null
                        try { svc.shutdown() } catch (x: Exception) {}
                        if (System.currentTimeMillis() - t0 > 5000) wakeFails = 0
                        wakeFails++
                        if (wakeFails >= 6) {
                            useFallback = true
                            status("Listening for Jarvis (basic mode)")
                            fallbackLoop()
                        } else main.postDelayed({ resume() }, 1000)
                    }
                }
                override fun onTimeout() {}
            })
            if (!ok) { svc.shutdown(); throw RuntimeException("microphone busy") }
            wakeSvc = svc
            setState("wake")
            status("Listening for Jarvis")
        } catch (e: Exception) {
            wakeFails++
            trail("wake start failed #$wakeFails: $e")
            if (wakeFails >= 6) {
                useFallback = true
                status("Listening for Jarvis (basic mode)")
                fallbackLoop()
            } else main.postDelayed({ resume() }, 250)
        }
    }

    private fun heard(h: String?) {
        if (h == null || waking || wakeWords.none { h.contains(it) }) return
        waking = true
        main.post {
            stopWake()
            greet()
        }
    }

    private fun stopWake() {
        try { wakeSvc?.stop(); wakeSvc?.shutdown() } catch (e: Exception) {}
        wakeSvc = null
    }

    private fun recognize(done: (String?) -> Unit) {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    done(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase(Locale.getDefault()))
                }
                override fun onError(e: Int) { trail("recognizer error $e"); done(null) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val tag = loc().toLanguageTag()
        recognizer?.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1800L)
                .putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1800L)
        )
    }

    private fun listenCommand() {
        setState("command")
        main.removeCallbacks(watch)
        main.postDelayed(watch, 20000)
        val silent = getSharedPreferences("pip", MODE_PRIVATE).getBoolean("silent", false)
        if (silent && model != null && !useFallback) {
            offlineDone = false
            listenOffline()
        } else {
            recognize { t -> afterHeard(t ?: "") }
        }
    }

    private fun afterHeard(raw: String) {
        var s = raw
        fallbackWords.forEach { s = s.replace(it, "") }
        s = s.trim(',', '.', ' ')
        if (s.isEmpty()) {
            trail("heard nothing")
            main.postDelayed({ resume() }, 400)
        } else {
            status("Heard: $s")
            dispatch(s)
        }
    }

    // Silent mode: the offline Vosk model listens for the command, so Google's listening sound never plays.
    private fun listenOffline() {
        try {
            val rec = cmdRec ?: Recognizer(model!!, 16000.0f).also { cmdRec = it }
            val svc = SpeechService(rec, 16000.0f)
            wakeSvc = svc
            svc.startListening(object : VoskListener {
                override fun onPartialResult(h: String?) {}
                override fun onResult(h: String?) { gotOffline(h) }
                override fun onFinalResult(h: String?) { gotOffline(h) }
                override fun onError(e: Exception?) { main.post { resume() } }
                override fun onTimeout() { main.post { resume() } }
            }, 9000)
        } catch (e: Exception) {
            trail("offline listen failed: $e")
            main.post { resume() }
        }
    }

    private fun gotOffline(h: String?) {
        val t = try { JSONObject(h ?: "{}").optString("text") } catch (e: Exception) { "" }
        if (t.isBlank() || offlineDone) return
        offlineDone = true
        main.post { stopWake(); afterHeard(t) }
    }

    private fun fallbackLoop() {
        if (!running) return
        setState("wake")
        recognize { t ->
            val w = if (t == null) null else fallbackWords.firstOrNull { t.contains(it) }
            if (t == null || w == null) {
                main.postDelayed({ fallbackLoop() }, 300)
            } else {
                val cmd = t.substringAfter(w).trimStart(',', '.', ' ')
                if (cmd.isNotEmpty()) dispatch(cmd) else greet()
            }
        }
    }

    private fun dispatch(text: String) {
        setState("busy")
        endConvo = false
        replying = true
        trail("command: $text")
        status("Thinking...")
        ActivityLog.add(this, text)
        main.removeCallbacks(watch)
        main.postDelayed(watch, 40000)
        commands.handle(text)
    }

    private fun finished() {
        main.post {
            main.removeCallbacks(watch)
            val convo = getSharedPreferences("pip", MODE_PRIVATE).getBoolean("convo", true)
            val reply = replying
            replying = false
            val listenNext = afterSpeech == 2 || (!endConvo && (chatFollowUp || (convo && reply)))
            chatFollowUp = false
            afterSpeech = 0
            trail("finished speaking, listenNext=$listenNext")
            if (listenNext) main.postDelayed({ listenCommand() }, 400)
            else main.postDelayed({ resume() }, 600)
        }
    }

    // ---------- voice ----------
    private fun loc(): Locale {
        val l = getSharedPreferences("pip", MODE_PRIVATE).getString("lang", "")?.trim() ?: ""
        return if (l.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(l)
    }

    private fun ttsLoc(): Locale {
        val british = getSharedPreferences("pip", MODE_PRIVATE).getBoolean("british", true)
        if (british && loc().language == "en" && tts.isLanguageAvailable(Locale.UK) >= TextToSpeech.LANG_AVAILABLE) return Locale.UK
        return loc()
    }

    private fun pickVoice() {
        try {
            val l = tts.language ?: return
            val vs = tts.voices?.filter { it.locale.language == l.language && (l.country.isEmpty() || it.locale.country == l.country) } ?: return
            val male = vs.firstOrNull { v -> listOf("gbb", "gbd", "rjs").any { v.name.contains(it) } }
            (male ?: vs.maxByOrNull { it.quality })?.let { tts.voice = it }
        } catch (e: Exception) {}
    }

    private fun speak(msg: String) {
        tts.setPitch(getSharedPreferences("pip", MODE_PRIVATE).getFloat("pitch", 0.9f))
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // Spoken once when Jarvis comes online. It never says the wake word, so it cannot trigger itself.
    private fun startup() {
        val p = getSharedPreferences("pip", MODE_PRIVATE)
        if (!p.getBoolean("greet", true) || !ttsReady) {
            resume()
            return
        }
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening"
        setState("busy")
        main.removeCallbacks(watch)
        main.postDelayed(watch, 20000)
        speak("$part, ${Answers.title(this)}. All systems are online. Battery at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent.")
    }

    private fun greet() {
        val p = getSharedPreferences("pip", MODE_PRIVATE)
        setState("busy")
        main.removeCallbacks(watch)
        if (!p.getBoolean("greet", true)) {
            main.postDelayed({ listenCommand() }, 150)
            return
        }
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening"
        val t = Answers.title(this)
        val lines = listOf(
            "At your service, $t.",
            "Yes, $t?",
            "$part, $t. How may I assist?",
            "Standing by, $t.",
            "How may I help, $t?",
            "Welcome back, $t."
        )
        afterSpeech = 2
        main.postDelayed(watch, 15000)
        speak(lines.random())
    }

    override fun onDestroy() {
        running = false
        alive = false
        main.removeCallbacksAndMessages(null)
        stopWake()
        recognizer?.destroy()
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (e: Exception) {}
        tts.shutdown()
        super.onDestroy()
    }
}
